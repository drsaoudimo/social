<?php
// Plugin Name
$name = 'Announcements';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.0.7';

// Plugin Type
$type = '5';

// Plugin Priority
$priority = 0;
?>