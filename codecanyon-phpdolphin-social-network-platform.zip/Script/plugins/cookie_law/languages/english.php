<?php

$LNG['plugin_cookies_text'] = 'We use cookies to improve your experience on our website. By browsing this website, you agree to our use of cookies.';
$LNG['plugin_cookies_ok'] = 'OK';
$LNG['plugin_cookies_more_info'] = 'More Info';
$LNG['plugin_cookie_law_position'] = 'Position';
$LNG['plugin_cookie_law_position_sub'] = 'The banner\'s position';
$LNG['plugin_cookie_law_color'] = 'Color';
$LNG['plugin_cookie_law_color_sub'] = 'The banner\'s color';
$LNG['plugin_cookie_law_url'] = 'URL';
$LNG['plugin_cookie_law_url_sub'] = 'The Cookie Policy URL';
$LNG['plugin_cookie_law_top'] = 'Top';
$LNG['plugin_cookie_law_bottom'] = 'Bottom';
$LNG['plugin_cookie_law_save'] = 'Save';