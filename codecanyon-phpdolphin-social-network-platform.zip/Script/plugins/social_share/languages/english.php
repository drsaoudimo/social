<?php

$LNG['plugin_social_share_services'] = 'Services';
$LNG['plugin_social_share_services_sub'] = 'The services for which the share button should be enabled';
$LNG['plugin_social_share_save'] = 'Save';