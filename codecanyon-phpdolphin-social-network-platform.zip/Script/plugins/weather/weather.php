<?php
function weather() {
	
}
?>