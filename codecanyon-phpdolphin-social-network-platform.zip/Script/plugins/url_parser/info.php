<?php
// Plugin Name
$name = 'URL Parser';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.0.7';

// Plugin Type
$type = '18d';

// Plugin Priority
$priority = 0;
?>