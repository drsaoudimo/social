<?php
// Plugin Name
$name = 'Dislike';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.1.3';

// Plugin Type
$type = '789';

// Plugin Priority
$priority = 0;
?>