<?php

$LNG['plugin_dislike_dislike'] = 'Dislike';
$LNG['plugin_dislike_disliked'] = 'Disliked';
$LNG['plugin_dislike_disliked_this'] = '%s disliked this';