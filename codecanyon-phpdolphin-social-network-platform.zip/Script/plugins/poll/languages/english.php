<?php

$LNG['plugin_poll_final_results'] = 'Final results. %s votes.';
$LNG['plugin_poll_votes'] = '%s votes.';
$LNG['plugin_poll_add_answer'] = '+ Add answer';
$LNG['plugin_poll_answer'] = 'Answer';
$LNG['plugin_poll_duration'] = 'Duration (number of days)';
$LNG['plugin_poll_vote'] = 'Vote';