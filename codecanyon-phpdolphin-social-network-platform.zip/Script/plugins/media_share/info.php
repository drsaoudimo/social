<?php
// Plugin Name
$name = 'Media Share';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.1.5';

// Plugin Type
$type = '189ed';

// Plugin Priority
$priority = 10;
?>